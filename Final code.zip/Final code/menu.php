  <link rel="stylesheet" href="style-menu-home.css">


<input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon"/>
  <label for="menu-icon"></label>
  <nav class="nav"> 		
    <ul class="pt-5">
      <li><a href="obers-page.php" target ="_self">Obers</a></li>
      <li><a href="kassa-page.php" target ="_self">kassa</a></li>
      <li><a href="keuken-page.php" target ="_self">keuken</a></li>
      <li><a href="bar-page.php" target ="_self">Bar</a></li>
      <li><a href="beheer-personeel.php" target ="_self">Account-beheer</a></li>
      <li><a href="loguit.php" id="signout" target ="_self" class="navigation-link">loguit</a></li>
    </ul>
  </nav>