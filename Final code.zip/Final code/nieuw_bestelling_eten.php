<?php

include_once 'Database.php';

if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $sql = "INSERT INTO bestelling_eten VALUES (:code, :tafel_nr, :gerecht1, :gerecht2, :gerecht3, :gerecht4, :gerecht5, :opmerkingen, :afhaal_of_restaurant, :gewenst_ophaal_tijd, :created_at )";
   
    $placeholders = [
        'code' => NULL,
        'tafel_nr' => $_POST['tafel_nr'],
        'gerecht1' => $_POST['gerecht1'],
        'gerecht2' => $_POST['gerecht2'],
        'gerecht3' => $_POST['gerecht3'],
        'gerecht4' => $_POST['gerecht4'],
        'gerecht5' => $_POST['gerecht5'],
        'opmerkingen' => $_POST['opmerkingen'],
        'afhaal_of_restaurant' => $_POST['afhaal_of_restaurant'],
        'gewenst_ophaal_tijd' => $_POST['gewenst_ophaal_tijd'],
        'created_at' => $_POST['created_at']

    ];

    $db = new database();
    $db->insert($sql, $placeholders, 'obers-page.php');
}
?>
<link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">

<form class="form_eten" action="nieuw_bestelling_eten.php" method="post">
  <input class="input" type="text" name="tafel_nr" placeholder="<?php echo isset($tafel_nr) ? $tafel_nr : 'tafel_nr' ?>">
  
  <select class="input" name="gerecht1" placeholder="<?php echo isset($gerecht1) ? $gerecht1 : 'gerecht1' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">ijs choco </option>
      <option value="ijs-vanille">ijs vanille </option>
      <option value="ijs-aarbei">ijs aarbei </option>
      <option value="ijs-alles">ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
  <select class="input" name="gerecht2" placeholder="<?php echo isset($gerecht2) ? $gerecht2 : 'gerecht2' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">ijs choco </option>
      <option value="ijs-vanille">ijs vanille </option>
      <option value="ijs-aarbei">ijs aarbei </option>
      <option value="ijs-alles">ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>

  <select class="input" name="gerecht3" placeholder="<?php echo isset($gerecht3) ? $gerecht3 : 'gerecht3' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">ijs choco </option>
      <option value="ijs-vanille">ijs vanille </option>
      <option value="ijs-aarbei">ijs aarbei </option>
      <option value="ijs-alles">ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
  <select class="input" name="gerecht4" placeholder="<?php echo isset($gerecht4) ? $gerecht4 : 'gerecht4' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">ijs choco </option>
      <option value="ijs-vanille">ijs vanille </option>
      <option value="ijs-aarbei">ijs aarbei </option>
      <option value="ijs-alles">ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
  <select class="input" name="gerecht5" placeholder="<?php echo isset($gerecht5) ? $gerecht5 : 'gerecht5' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">ijs choco </option>
      <option value="ijs-vanille">ijs vanille </option>
      <option value="ijs-aarbei">ijs aarbei </option>
      <option value="ijs-alles">ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
<input class="input" type="text" name="opmerkingen" placeholder="<?php echo isset($opmerkingen) ? $opmerkingen : 'opmerkingen' ?>">

  <select class="input" name="afhaal_of_restaurant" placeholder="<?php echo isset($afhaal_of_restaurant) ? $afhaal_of_restaurant : 'afhaal_of_restaurant' ?>">  
  <option value="AFHAAL">Afhaal?</option>
    <option value="RESTAURANT">Hier op eten?</option>
  </select>
  
  <input class="input" type="ttext" name="gewenst_ophaal_tijd" placeholder="<?php echo isset($gewenst_ophaal_tijd) ? $gewenst_ophaal_tijd : 'is er een gewenste afhaal tijd? nee? laat leeg...' ?>">
  <input class="input" type="text" name="created_at" placeholder="<?php echo isset($created_at) ? $created_at : 'Hoe laat is het nu?' ?>">


  <input id="button-voegtoe" type="submit" name="submit" value="Plaats bestelling">
</form>

</body>