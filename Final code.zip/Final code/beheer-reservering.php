<link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">
  <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>
  <title>RESERVATIE-BEHEER</title>
<body>

<div class="sectionreservaties">

<!------------reserveren column----------->
  <?php
  include_once 'Database.php';
  $db = new database();
  $reservaties = $db->select("SELECT reservatienummer, reservatie_naam, aantal_personen, allergieën, opmerkingen, reservatie_tijd  FROM reservaties", []);

  $columns = array_keys($reservaties[0]);
  $row_data = array_values($reservaties);

  ?>

  <table id="reservaties">
    <tr>
      <?php foreach ($columns as $column) { ?>
        <th>
          <strong>
            <?php echo $column; ?>
          </strong>
        </th>

      <?php    }    ?>
      <th colspan="3">actie</th>
    </tr>
    <?php foreach ($row_data as $row) { ?>
      <tr>
        <?php

        $reservatie_id = $row['reservatienummer'];

        foreach ($row as $data) { ?>
          <td>
            <?php echo $data; ?>
          </td>
        <?php } ?>

        <td>
          <a class="tooltip" href="edit_reservering.php?reservatie_id=<?php echo $reservatie_id ?>"><i class="fas fa-pencil-alt"></i>
            <p class="tooltiptext">Edit</p>
          </a>

          <a class="tooltip" href="delete_reservering.php?reservatie_id=<?php echo $reservatie_id ?>"><i class="fas fa-trash-alt"></i>
            <p class="tooltiptext">Delete</p>
          </a>
        </td>
      <?php
    }
      ?>

      </tr>

  </table>
  <?php include "nieuw_reservering.php"; ?>
</div>
  </body>
</html>