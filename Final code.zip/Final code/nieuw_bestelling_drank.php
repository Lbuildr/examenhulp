<?php

include_once 'Database.php';

if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $sql = "INSERT INTO bestelling_drank VALUES (:code, :hoort_bij_tafel_nr, :drank1, :drank2, :drank3, :drank4, :drank5 )";
   
    $placeholders = [
        'code' => NULL,
        'hoort_bij_tafel_nr' => $_POST['hoort_bij_tafel_nr'],
        'drank1' => $_POST['drank1'],
        'drank2' => $_POST['drank2'],
        'drank3' => $_POST['drank3'],
        'drank4' => $_POST['drank4'],
        'drank5' => $_POST['drank5']

    ];

    $db = new database();
    $db->insert($sql, $placeholders, 'obers-page.php');
}
?>
<link rel="stylesheet" href="style-beheer-bestelling-drank.css">

<form class="form_drank" action="nieuw_bestelling_drank.php" method="post">
  <input class="input" type="text" name="hoort_bij_tafel_nr" placeholder="<?php echo isset($hoort_bij_tafel_nr) ? $hoort_bij_tafel_nr : 'hoort_bij_tafel_nr' ?>">
  
  <select class="input" name="drank1" placeholder="<?php echo isset($drank1) ? $drank1 : 'drank1' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  
  <select class="input" name="drank2" placeholder="<?php echo isset($drank2) ? $drank2 : 'drank2' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>

  <select class="input" name="drank3" placeholder="<?php echo isset($drank3) ? $drank3 : 'drank3' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  
  <select class="input" name="drank4" placeholder="<?php echo isset($drank4) ? $drank4 : 'drank4' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  
  <select class="input" name="drank5" placeholder="<?php echo isset($drank5) ? $drank5 : 'drank5' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  

  <input id="button-voegtoe" type="submit" name="submit" value="Plaats bestelling">
</form>

</body>