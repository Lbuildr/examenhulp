<?php

if(isset($_GET['personeels_id'])){

    $sql = "DELETE FROM personeel WHERE personeelscode=:personeels_id";

    $placeholders = ['personeels_id' => $_GET['personeels_id']];


    include_once 'Database.php';

    $db =  new database();

    $db->delete($sql, $placeholders, 'beheer-personeel.php');


}else{

}


