<?php

include_once 'Database.php';

if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $sql = "INSERT INTO reservaties VALUES (:code, :reservatie_naam, :aantal_personen, :allergieën, :opmerkingen, :reservatie_tijd )";
   
    $placeholders = [
        'code' => NULL,
        'reservatie_naam' => $_POST['reservatie_naam'],
        'aantal_personen' => $_POST['aantal_personen'],
        'allergieën' => $_POST['allergieën'],
        'opmerkingen' => $_POST['opmerkingen'],
        'reservatie_tijd' => $_POST['reservatie_tijd'],

    ];

    $db = new database();
    $db->insert($sql, $placeholders, 'kassa-page.php');
}
?>
<link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">

<form class="form_drank" action="nieuw_reservering.php" method="post">
  <input class="input" type="text" name="reservatie_naam" placeholder="<?php echo isset($reservatie_naam) ? $reservatie_naam : 'reservatie_naam' ?>">
  <input class="input" type="text" name="aantal_personen" placeholder="<?php echo isset($aantal_personen) ? $aantal_personen : 'aantal_personen' ?>">
  <input class="input" type="text" name="allergieën" placeholder="<?php echo isset($allergieën) ? $allergieën : 'allergieën' ?>">
  <input class="input" type="text" name="opmerkingen" placeholder="<?php echo isset($opmerkingen) ? $opmerkingen : 'opmerkingen' ?>">
  <input class="input" type="text" name="reservatie_tijd" placeholder="<?php echo isset($reservatie_tijd) ? $reservatie_tijd : 'reservatie_tijd' ?>">
  
  <input id="button-voegtoe" type="submit" name="submit" value="Plaats Reservering">
</form>

</body>