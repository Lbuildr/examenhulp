<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">
    <title>EDIT-BESTELD-ETEN</title>
</head>

<body>

    <?php

    include_once 'Database.php';
    $db =  new database();

    if (isset($_GET['bestelling_eten_id'])){
    $sql = "SELECT * FROM bestelling_eten WHERE bestellingsnummer_eten=:code";
    $result = $db->select($sql, ['code' => $_GET['bestelling_eten_id']]);
    if (count($result) > 0) {
        $tafel_nr = $result[0]['tafel_nr'];
        $gerecht1 = $result[0]['gerecht1'];
        $gerecht2 = $result[0]['gerecht2'];
        $gerecht3 = $result[0]['gerecht3'];
        $gerecht4 = $result[0]['gerecht4'];
        $gerecht5 = $result[0]['gerecht5'];
        $opmerkingen = $result[0]['opmerkingen'];
        $afhaal_of_restaurant = $result[0]['afhaal_of_restaurant']; 
        $gewenst_ophaal_tijd = $result[0]['gewenst_ophaal_tijd']; 
        $created_at = $result[0]['created_at'];
    }
}


if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE bestelling_eten SET tafel_nr=:tafel_nr, gerecht1=:gerecht1, gerecht2=:gerecht2, gerecht3=:gerecht3, gerecht4=:gerecht4, gerecht5=:gerecht5, opmerkingen=:opmerkingen, gewenst_ophaal_tijd=:gewenst_ophaal_tijd, afhaal_of_restaurant=:afhaal_of_restaurant, created_at=:created_at WHERE bestellingsnummer_eten = :code;";

        $placeholders = [
            'code' => $_POST['bestellingsnummer_eten'],
            'tafel_nr' => $_POST['tafel_nr'],
            'gerecht1' => $_POST['gerecht1'],
            'gerecht2' => $_POST['gerecht2'],
            'gerecht3' => $_POST['gerecht3'],
            'gerecht4' => $_POST['gerecht4'],
            'gerecht5' => $_POST['gerecht5'],
            'opmerkingen' => $_POST['opmerkingen'],
            'afhaal_of_restaurant' => $_POST['afhaal_of_restaurant'],
            'gewenst_ophaal_tijd' => $_POST['gewenst_ophaal_tijd'],
            'created_at' => $_POST['created_at'],
        ];

        $db->update($sql, $placeholders,"keuken-page.php" );
    }
    ?>


    <form class="form" action="edit_bestel_eten.php" method="post">
        <input type="hidden" name="bestellingsnummer_eten" value="<?php echo isset($_GET['bestelling_eten_id']) ? $_GET['bestelling_eten_id'] : ''; ?>">
        <input class="input" type="text" name="tafel_nr" value="<?php echo isset($tafel_nr) ? $tafel_nr : 'tafel_nr' ?>">

  <select class="input" name="gerecht1" value="<?php echo isset($gerecht1) ? $gerecht1 : 'gerecht1' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">Ijs choco </option>
      <option value="ijs-vanille">Ijs vanille </option>
      <option value="ijs-aarbei">Ijs aarbei </option>
      <option value="ijs-alles">Ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
  <select class="input" name="gerecht2" value="<?php echo isset($gerecht2) ? $gerecht2 : 'gerecht2' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">Ijs choco </option>
      <option value="ijs-vanille">Ijs vanille </option>
      <option value="ijs-aarbei">Ijs aarbei </option>
      <option value="ijs-alles">Ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>

  <select class="input" name="gerecht3" value="<?php echo isset($gerecht3) ? $gerecht3 : 'gerecht3' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">Ijs choco </option>
      <option value="ijs-vanille">Ijs vanille </option>
      <option value="ijs-aarbei">Ijs aarbei </option>
      <option value="ijs-alles">Ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
  <select class="input" name="gerecht4" value="<?php echo isset($gerecht4) ? $gerecht4 : 'gerecht4' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">Ijs choco </option>
      <option value="ijs-vanille">Ijs vanille </option>
      <option value="ijs-aarbei">Ijs aarbei </option>
      <option value="ijs-alles">Ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
  <select class="input" name="gerecht5" value="<?php echo isset($gerecht5) ? $gerecht5 : 'gerecht5' ?>">  
  <optgroup label="voorgerechten">
      <option selected="selected" value="0">selecteer eten</option>
      <option value="k-soep">kippen soep</option>
      <option value="T-soep">Tomaten soep </option>
      <option value="M-salade">Mozerela salade</option>
      <option value="Salade">Salade </option>
      <option value="loempia">Loempia's </option>
    </optgroup>
    <optgroup label="Schotels">
      <option value="S-schotel">Shoarma schotel</option>
      <option value="S-schotel+kebab">Shoarma schotel met kebab </option>
      <option value="S-schtoel+shashlick">Shoarma schotel met shashlick</option>
      <option value="D-schotel">Döner schotel </option>
      <option value="D-schotel+kebab">Döner schotel met kebab </option>
      <option value="D-schotel+kipvleugels">Doner schotel met kipvleugels (2)</option>
    </optgroup>
    <optgroup label="Frietuur">
      <option value="P-zonder">Patat zonder </option>
      <option value="P-saus">Patat Saus </option>
      <option value="Frikandel">Frikandel </option>
      <option value="kroket">Kroket </option>
    </optgroup>
    <optgroup label="Nagerechten">
      <option value="ijs-choco">Ijs choco </option>
      <option value="ijs-vanille">Ijs vanille </option>
      <option value="ijs-aarbei">Ijs aarbei </option>
      <option value="ijs-alles">Ijs alle 3 smaken </option>
      <option value="baklave">Baklava </option>
      <option value="kunefe">Kunefe </option>
      <option value="Tiramisu">Tiramisu </option>
    </optgroup>
</select>
  
<input class="input" type="text" name="opmerkingen" value="<?php echo isset($opmerkingen) ? $opmerkingen : 'opmerkingen' ?>">

  <select class="input" name="afhaal_of_restaurant" value="<?php echo isset($afhaal_of_restaurant) ? $afhaal_of_restaurant : 'afhaal_of_restaurant' ?>">  
  <option value="AFHAAL">Afhaal?</option>
    <option value="RESTAURANT">Hier op eten?</option>
  </select>
  
  <input class="input" type="time" name="gewenst_ophaal_tijd" value="<?php echo isset($gewenst_ophaal_tijd) ? $gewenst_ophaal_tijd : 'gewenst_ophaal_tijd' ?>">
  <input class="input" type="text" name="created_at" value="<?php echo isset($created_at) ? $created_at : 'Hoe laat is het nu?' ?>">
 
  <input id="button-voegtoe" type="submit" name="submit" value="Pas bestelling aan">
    </form>
</body>

</html>