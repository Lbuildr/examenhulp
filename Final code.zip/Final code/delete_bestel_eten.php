<?php

if(isset($_GET['bestelling_eten_id'])){

    $sql = "DELETE FROM bestelling_eten WHERE bestellingsnummer_eten=:bestelling_eten_id";

    $placeholders = ['bestelling_eten_id' => $_GET['bestelling_eten_id']];


    include_once 'Database.php';

    $db =  new database();

    $db->delete($sql, $placeholders, 'keuken-page.php');


}else{

}


