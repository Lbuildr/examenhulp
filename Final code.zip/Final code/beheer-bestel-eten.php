<link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">
  <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>
  <title>RESERVATIE-BEHEER</title>
<body>

<div class="sectiongerechten">



<!------------eten column----------->
  <?php
  include_once 'Database.php';
  $db = new database();
  $bestelling_eten = $db->select("SELECT bestellingsnummer_eten, tafel_nr, gerecht1, gerecht2, gerecht3, gerecht4, gerecht5, opmerkingen, gewenst_ophaal_tijd, created_at, afhaal_of_restaurant FROM bestelling_eten", []);

  $columns = array_keys($bestelling_eten[0]);
  $row_data = array_values($bestelling_eten);

  ?>

  <table id="bestelling_eten">
    <tr>
      <?php foreach ($columns as $column) { ?>
        <th>
          <strong>
            <?php echo $column; ?>
          </strong>
        </th>

      <?php    }    ?>
      <th colspan="3">actie</th>
    </tr>
    <?php foreach ($row_data as $row) { ?>
      <tr>
        <?php

        $bestelling_eten_id = $row['bestellingsnummer_eten'];

        foreach ($row as $data) { ?>
          <td>
            <?php echo $data; ?>
          </td>
        <?php } ?>

        <td>
          <a class="tooltip" href="edit_bestel_eten.php?bestelling_eten_id=<?php echo $bestelling_eten_id ?>"><i class="fas fa-pencil-alt"></i>
            <p class="tooltiptext">bewerk bestelling</p>
          </a>

          <a class="tooltip" href="delete_bestel_eten.php?bestelling_eten_id=<?php echo $bestelling_eten_id ?>"><i class="fas fa-trash-alt"></i>
            <p class="tooltiptext">markeer als done en verwijder</p>
          </a>
        </td>
      <?php
    }
      ?>

      </tr>

  </table>
</div>
  </body>
</html>