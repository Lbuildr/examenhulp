<link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">
  <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>
  <title>RESERVATIE-BEHEER</title>
<body>

<div class="sectiondrank">



<!------------eten column----------->
  <?php
  include_once 'Database.php';
  $db = new database();
  $bestelling_drank = $db->select("SELECT bestellingsnummer_drank, hoort_bij_tafel_nr, drank1, drank2, drank3, drank4, drank5 FROM bestelling_drank", []);

  $columns = array_keys($bestelling_drank[0]);
  $row_data = array_values($bestelling_drank);

  ?>

  <table id="bestelling_drank">
    <tr>
      <?php foreach ($columns as $column) { ?>
        <th>
          <strong>
            <?php echo $column; ?>
          </strong>
        </th>

      <?php    }    ?>
      <th colspan="3">actie</th>
    </tr>
    <?php foreach ($row_data as $row) { ?>
      <tr>
        <?php

        $bestelling_drank_id = $row['bestellingsnummer_drank'];

        foreach ($row as $data) { ?>
          <td>
            <?php echo $data; ?>
          </td>
        <?php } ?>

        <td>
          <a class="tooltip" href="edit_bestel_drank.php?bestelling_drank_id=<?php echo $bestelling_drank_id ?>"><i class="fas fa-pencil-alt"></i>
            <p class="tooltiptext">bewerk bestelling</p>
          </a>

          <a class="tooltip" href="delete_bestel_drank.php?bestelling_drank_id=<?php echo $bestelling_drank_id ?>"><i class="fas fa-trash-alt"></i>
            <p class="tooltiptext">markeer als done en verwijder</p>
          </a>
        </td>
      <?php
    }
      ?>

      </tr>

  </table>
</div>
  </body>
</html>