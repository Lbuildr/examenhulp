<body>

    <?php

    include_once 'Database.php';
    $db =  new database();

    if (isset($_GET['reservatie_id'])){
    $sql = "SELECT * FROM reservaties WHERE reservatienummer=:code";
    $result = $db->select($sql, ['code' => $_GET['reservatie_id']]);
    if (count($result) > 0) {
        $reservatie_naam = $result[0]['reservatie_naam'];
        $aantal_personen = $result[0]['aantal_personen'];
        $reservatie_tijd = $result[0]['reservatie_tijd'];
    }
}


if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE reservaties SET reservatie_naam=:reservatie_naam, aantal_personen=:aantal_personen, reservatie_tijd=:reservatie_tijd WHERE reservatienummer = :code;";

        $placeholders = [
            'code' => $_POST['reservatienummer'],
            'reservatie_naam' => $_POST['reservatie_naam'],
            'aantal_personen' => $_POST['aantal_personen'],
            'reservatie_tijd' => $_POST['reservatie_tijd'],
        ];

        $db->update($sql, $placeholders,"kassa-page.php" );
    }
    ?>


    <form action="edit_reservering.php" method="post">
        <input type="hidden" name="reservatienummer" value="<?php echo isset($_GET['reservatie_id']) ? $_GET['reservatie_id'] : ''; ?>">
        <input type="text" name="reservatie_naam" value="<?php echo isset($reservatie_naam) ? $reservatie_naam : 'reservatie_naam' ?>">
        <input type="text" name="aantal_personen" value="<?php echo isset($aantal_personen) ? $aantal_personen : 'aantal_personen' ?>">
        <input type="text" name="reservatie_tijd" value="<?php echo isset($reservatie_tijd) ? $reservatie_tijd : 'reservatie_tijd' ?>">
        <input type="submit" name="submit" value="Wijzig">
    </form>

</body>

</html>