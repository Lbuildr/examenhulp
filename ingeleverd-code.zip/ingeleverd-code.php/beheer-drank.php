<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style-beheer-artikel.css">
  <title>ARTIKEL-BEHEER</title>
</head>

<body>
<?php include "menu-back-end.php"; ?>
  <div class="content">

  <div class="artikeltitel">Artikellen</div>

  <div class="sectionArtikel">

    <!-------Artikel Comumn------>
    <?php
    include_once 'Database.php';
    $db = new database();
    $artikel = $db->select("SELECT * FROM producten", []);

    $columns = array_keys($artikel[0]);
    $row_data = array_values($artikel);

    ?>

    <table id="artikelen">
      <tr>
        <?php foreach ($columns as $column) { ?>
          <th>
            <strong>
              <?php echo $column; ?>
            </strong>
          </th>

        <?php    }    ?>
        <th colspan="3">actie</th>
      </tr>
      <?php foreach ($row_data as $row) { ?>
        <tr>
          <?php

          $artikel_id = $row['artikelcode'];

          foreach ($row as $data) { ?>
            <td>
              <?php echo $data; ?>
            </td>
          <?php } ?>

          <td>
            <a class="tooltip" href="edit_artikel.php?artikel_id=<?php echo $artikel_id ?>"><i class="fas fa-pencil-alt"></i>
              <p class="tooltiptext">Edit</p>
            </a>

            <a class="tooltip" href="delete_artikel.php?artikel_id=<?php echo $artikel_id ?>"><i class="fas fa-trash-alt"></i>
              <p class="tooltiptext">Delete</p>
            </a>
          </td>
        <?php
      }
        ?>

        </tr>

    </table>

    <?php include "nieuw_artikel.php"; ?>

  </div>
  </div>
</body>

</html>