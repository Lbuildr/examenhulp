<body>
<?php include "menu.php" ?>

<div class="sectiongerechten">



<!------------personeel column----------->
  <?php
  include_once 'Database.php';
  $db = new database();
  $personeel = $db->select("SELECT personeelscode, voornaam, achternaam, straatnaam, huisnummer, postcode, stad FROM personeel", []);

  $columns = array_keys($personeel[0]);
  $row_data = array_values($personeel);

  ?>

  <table id="personeel">
    <tr>
      <?php foreach ($columns as $column) { ?>
        <th>
          <strong>
            <?php echo $column; ?>
          </strong>
        </th>

      <?php    }    ?>
      <th colspan="3">actie</th>
    </tr>
    <?php foreach ($row_data as $row) { ?>
      <tr>
        <?php

        $personeels_id = $row['personeelscode'];

        foreach ($row as $data) { ?>
          <td>
            <?php echo $data; ?>
          </td>
        <?php } ?>

        <td>
          <a class="tooltip" href="edit_personeel.php?personeels_id=<?php echo $personeels_id ?>"><i class="fas fa-pencil-alt"></i>
            <p class="tooltiptext">Edit</p>
          </a>

          <a class="tooltip" href="delete_personeel.php?personeels_id=<?php echo $personeels_id ?>"><i class="fas fa-trash-alt"></i>
            <p class="tooltiptext">Delete</p>
          </a>
        </td>
      <?php
    }
      ?>

      </tr>

  </table>
  <?php include "nieuw_personeel.php"; ?>
</div>
  </body>
</html>