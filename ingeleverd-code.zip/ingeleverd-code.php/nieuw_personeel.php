  <?php

    include_once 'Database.php';

    if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "INSERT INTO personeel VALUES (:code, :voornaam, :achternaam, :username, :password, :straatnaam, :huisnummer, :postcode, :stad, :usertype, :created_at )";
       
        $placeholders = [
            'code' => NULL,
            'voornaam' => $_POST['voornaam'],
            'achternaam' => $_POST['achternaam'],
            'username' => $_POST['username'],
            'password' => $_POST['password'],
            'straatnaam' => $_POST['straatnaam'],
            'huisnummer' => $_POST['huisnummer'],
            'postcode' => $_POST['postcode'],
            'stad' => $_POST['stad'],
            'usertype' => $_POST['usertype'],
            'created_at' => $_POST['created_at']

        ];

        $db = new database();
        $db->insert($sql, $placeholders, 'beheer-personeel.php');
    }
    ?>
<link rel="stylesheet" href="style-beheer-personeel.css">

  <form class="form" action="nieuw_personeel.php" method="post">
      <input class="input" type="text" name="voornaam" placeholder="<?php echo isset($voornaam) ? $voornaam : 'voornaam' ?>">
      <input class="input" type="text" name="achternaam" placeholder="<?php echo isset($achternaam) ? $achternaam : 'achternaam' ?>">
      <input class="input" type="text" name="username" placeholder="<?php echo isset($username) ? $username : 'username' ?>">
      <input class="input" type="text" name="password" placeholder="<?php echo isset($password) ? $password : 'password' ?>">
      <input class="input" type="text" name="straatnaam" placeholder="<?php echo isset($straatnaam) ? $straatnaam : 'straatnaam' ?>">
      <input class="input" type="text" name="huisnummer" placeholder="<?php echo isset($huisnummer) ? $huisnummer : 'huisnummer' ?>">
      <input class="input" type="text" name="postcode" placeholder="<?php echo isset($postcode) ? $postcode : 'postcode' ?>">
      <input class="input" type="text" name="stad" placeholder="<?php echo isset($stad) ? $stad : 'stad' ?>">
      <input class="input" type="time" name="created_at" placeholder="<?php echo isset($created_at) ? $created_at : 'created_at' ?>">
      <select class="input" name="usertype" placeholder="<?php echo isset($usertype) ? $usertype : 'usertype' ?>">  
      <option value="1">Ceo</option>
        <option value="2">Filiaalmanager</option>
        <option value="3">Personeel</option>
      </select>
      <input id="button-voegtoe" type="submit" name="submit" value="join the club!">
  </form>

  </body>