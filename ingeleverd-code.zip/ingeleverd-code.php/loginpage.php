<?php
// Initialize the session
session_start();
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT * FROM personeel WHERE username=? LIMIT 1"; 
        
        
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            // $stmt->bindParam(":username",PDO::PARAM_STR);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            // Attempt to execute the prepared statement
            if($stmt->execute(array($param_username))){
                // Check if username exists, if yes then verify password
                if($stmt->rowCount() == 1){
                    if($row = $stmt->fetch()){
                        $personeelscode = $row["personeelscode"];
                        $username = $row["username"];
                        $hashed_password = $row["password"];
                        $usertype_id = $row["usertype_id"];
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["personeelscode"] = $personeelscode;
                            $_SESSION["username"] = $username; 
                            $_SESSION["usertype_id"] = $usertype_id;               
                            
                            // Redirect user to welcome page
                            header("location: landingpage.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Geen Geldige Wachtwoord.";
                        }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Geen bekende Gebruikersnaam!";
                }
            } else{
                echo "Oops! Iets ging fout (error-code:0000).";
                }

            // Close statement
            unset($stmt);
            }
        }
    }
    
    // Close connection
    unset($pdo);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style-loginpage-form.css">
    <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>

</head>
<body>
 

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

    <form class="login-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <div class="container">
  <div class="left">
    <div class="header">
        <a class="geen-acc knop" href="registreer.php">Heeft u nog geen account?</a>
      <h2 class="animation a1">Welcome Terug</h2>
      <h4 class="animation a2">Log in to your account using email and password</h4>
      <span class="invalid-feedback"><?php echo $username_err; ?></span>
      <span class="invalid-feedback"><?php echo $password_err; ?></span>
    </div>
    <div class="form">
      <input class="form-field animation a3" type="username" name="username" placeholder="gebruikersnaam" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
      <input class="form-field animation a4" type="password" name="password" placeholder="wachtwoord" class="password <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
      <p id="button-vergeten" class="animation a5"><a href="#">Forgot Password</a></p>
      <input type="submit" id="button-login" class="animation a6" value="Login">
    </div>
  </div>
  <div class="right"></div>
</div>
    </form>


</body>
</html>