<?php

if(isset($_GET['bestelling_drank_id'])){

    $sql = "DELETE FROM bestelling_drank WHERE bestellingsnummer_drank=:bestelling_drank_id";

    $placeholders = ['bestelling_drank_id' => $_GET['bestelling_drank_id']];


    include_once 'Database.php';

    $db =  new database();

    $db->delete($sql, $placeholders, 'bar-page.php');


}else{

}


