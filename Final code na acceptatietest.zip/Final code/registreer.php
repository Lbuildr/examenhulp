<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = $voornaam = $achternaam = $straatnaam = $huisnummer = $postcode = $stad = $usertype_id = "";
$username_err = $password_err = $confirm_password_err = $voornaam_err = $achternaam_err = $straatnaam_err = $huisnummer_err = $postcode_err = $stad_err = $usertype_err_id = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        // Prepare a select statement
        $sql = "SELECT personeelscode FROM personeel WHERE username  = :username ";
        
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                if($stmt->rowCount() == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }

    // Validate voornaam
    if(empty(trim($_POST["voornaam"]))){
        $voornaam_err = "Vul uw voornaam in.";     
    } else{
        $voornaam = trim($_POST["voornaam"]);
        }

        // Validate achternaam
        if(empty(trim($_POST["achternaam"]))){
            $achternaam_err = "Vul uw achternaam in.";     
        } else{
            $achternaam = trim($_POST["achternaam"]);
            }

    
         // Validate straatnaam
         if(empty(trim($_POST["straatnaam"]))){
            $straatnaam_err = "vul uw straatnaam in";     
        } else{
            $straatnaam = trim($_POST["straatnaam"]);
            }
    

    
         // Validate huisnr
         if(empty(trim($_POST["huisnummer"]))){
            $huisnummer_err = "Vul uw huisnr in.";     
        } else{
            $huisnummer = trim($_POST["huisnummer"]);
            }
    

    
         // Validate postcode
         if(empty(trim($_POST["postcode"]))){
            $postcode_err = "Vul uw post code in.";     
        } else{
            $postcode = trim($_POST["usertype_id"]);
            }
    

         // Validate stad
         if(empty(trim($_POST["stad"]))){
            $stad_err = "Vul uw stad in.";     
        } else{
            $stad = trim($_POST["usertype_id"]);
            }

            // Validate confirm usertype
         if(empty(trim($_POST["usertype_id"]))){
            $usertype_err_id = "Please confirm usertype.";     
        } else{
            $usertype_id = trim($_POST["usertype_id"]);
            }
    }
        
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($voornaam_err) && empty($achternaam_err) && empty($straatnaam_err) && empty($huisnummer_err) && empty($postcode_err) && empty($stad_err) && empty($usertype_err_id)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO personeel (username, password, voornaam, achternaam, straatnaam, huisnummer, postcode, stad, usertype_id) VALUES (:username, :password, :voornaam, :achternaam, :straatnaam, :huisnummer, :postcode, :stad, :usertype_id)";
         
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
            $stmt->bindParam(":voornaam", $param_voornaam, PDO::PARAM_STR);
            $stmt->bindParam(":achternaam", $param_achternaam, PDO::PARAM_STR);
            $stmt->bindParam(":straatnaam", $param_straatnaam, PDO::PARAM_STR);
            $stmt->bindParam(":huisnummer", $param_huisnummer, PDO::PARAM_STR);
            $stmt->bindParam(":postcode", $param_postcode, PDO::PARAM_STR);
            $stmt->bindParam(":stad", $param_stad, PDO::PARAM_STR);
            $stmt->bindParam(":usertype_id", $param_usertype_id, PDO::PARAM_STR);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_voornaam = $voornaam;
            $param_achternaam = $achternaam;
            $param_straatnaam = $straatnaam;
            $param_huisnummer = $huisnummer;
            $param_postcode = $postcode;
            $param_stad = $stad;
            $param_usertype_id = $usertype_id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Redirect to login page
                header("location: landingpage.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }
    
    // Close connection
    unset($pdo);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="style-registreer-form.css">
    <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="registreer-form">
        <h2 >Account aanmaken</h2>
        <p>vul dit formulier in om een account aan te maken.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="username" placeholder="gebruikersnaam" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label></label>
                <input class="input" type="password" name="password" placeholder="Wachtwoord" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="password" name="confirm_password" placeholder="herhaal-wachtwoord" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="voornaam" placeholder="Voornaam" class="form-control <?php echo (!empty($voornaam_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $voornaam; ?>">
                <span class="invalid-feedback"><?php echo $voornaam_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="achternaam" placeholder="Achternaam" class="form-control <?php echo (!empty($achternaam_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $achternaam; ?>">
                <span class="invalid-feedback"><?php echo $achternaam_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="straatnaam" placeholder="Straatnaam" class="form-control <?php echo (!empty($straatnaam_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $straatnaam; ?>">
                <span class="invalid-feedback"><?php echo $straatnaam_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="huisnummer" placeholder="Huisnr" class="form-control <?php echo (!empty($huisnummer_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $huisnummer; ?>">
                <span class="invalid-feedback"><?php echo $huisnummer_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="postcode" placeholder="Postcode" class="form-control <?php echo (!empty($postcode_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $postcode; ?>">
                <span class="invalid-feedback"><?php echo $postcode_err; ?></span>
            </div>
            <div class="form-group">
                <label></label>
                <input class="input" type="text" name="stad" placeholder="Stad" class="form-control <?php echo (!empty($stad_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $stad; ?>">
                <span class="invalid-feedback"><?php echo $stad_err; ?></span>
            </div>
            
            <div class="form-group">
            <select class="input" name="usertype_id" class="form-control <?php echo (!empty($usertype_err_id)) ? 'is-invalid' : ''; ?>" value="<?php echo $usertype_err_id; ?>">
                <span class="invalid-feedback"><?php echo $usertype_err_id; ?></span>
                <option value="1">Ceo</option>
                <option value="2">Filiaalmanager</option>
                <option value="3">Personeel</option>
            </select>
            </div>

            <div class="form-buttons">
                <input type="submit" id="button-submit" class="btn btn-primary" value="Maak aan">
                <input type="reset" id="button-reset" class="btn btn-secondary ml-2" value="Begin opnieuw">
            </div>
        </form>
    </div>


<div class="login-pijl">
    <a href="landingpage.php"><i class="fas fa-long-arrow-alt-left"></i>
    <p>Heeft u al een account?</p></a>
    </div>    
</div>

    </body>
</html>