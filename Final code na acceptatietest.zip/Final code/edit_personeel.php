<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">
    <title>EDIT-PERSONEEL</title>
</head>

<body>

    <?php

    include_once 'Database.php';
    $db =  new database();

    if (isset($_GET['personeels_id'])){
    $sql = "SELECT * FROM personeel WHERE personeelscode=:code";
    $result = $db->select($sql, ['code' => $_GET['personeels_id']]);
    if (count($result) > 0) {
        $voornaam = $result[0]['voornaam'];
        $achternaam = $result[0]['achternaam'];
        $username = $result[0]['username'];
        $password = $result[0]['password'];
        $straatnaam = $result[0]['straatnaam'];
        $huisnummer = $result[0]['huisnummer'];
        $postcode = $result[0]['postcode'];
        $stad = $result[0]['stad'];
        $created_at = $result[0]['created_at'];
    }
}


if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE personeel SET voornaam=:voornaam, achternaam=:achternaam, username=:username, password=:password, straatnaam=:straatnaam, huisnummer=:huisnummer, postcode=:postcode, stad=:stad, usertype_id=:usertype_id, created_at=:created_at WHERE personeelscode = :code;";

        $placeholders = [
            'code' => $_POST['personeelscode'],
            'voornaam' => $_POST['voornaam'],
            'achternaam' => $_POST['achternaam'],
            'username' => $_POST['username'],
            'password' => $_POST['password'],
            'straatnaam' => $_POST['straatnaam'],
            'huisnummer' => $_POST['huisnummer'],
            'postcode' => $_POST['postcode'],
            'stad' => $_POST['stad'],
            'usertype_id' => $_POST['usertype_id'],
            'created_at' => $_POST['created_at'],
        ];

        $db->update($sql, $placeholders,"beheer-personeel.php" );
    }
    ?>

    <form action="edit_personeel.php" method="post">
        <input class="input" type="hidden" name="personeelscode" value="<?php echo isset($_GET['personeels_id']) ? $_GET['personeels_id'] : ''; ?>">
        <input class="input" type="text" name="voornaam" value="<?php echo isset($voornaam) ? $voornaam : 'voornaam' ?>">
        <input class="input" type="text" name="achternaam" value="<?php echo isset($achternaam) ? $achternaam : 'achternaam' ?>">
        <input class="input" type="text" name="username" value="<?php echo isset($username) ? $username : 'username' ?>">
        <input class="input" type="text" name="password" value="<?php echo isset($password) ? $password : 'password' ?>">
        <input class="input" type="text" name="straatnaam" value="<?php echo isset($straatnaam) ? $straatnaam : 'straatnaam' ?>">
        <input class="input" type="text" name="huisnummer" value="<?php echo isset($huisnummer) ? $huisnummer : 'huisnummer' ?>">
        <input class="input" type="text" name="postcode" value="<?php echo isset($postcode) ? $postcode : 'postcode' ?>">
        <input class="input" type="text" name="stad" value="<?php echo isset($stad) ? $stad : 'stad' ?>">
        <input class="input" type="text" name="usertype_id" value="<?php echo isset($usertype_id) ? $usertype_id : 'usertype_id' ?>">
        <input class="input" type="text" name="created_at" value="<?php echo isset($created_at) ? $created_at : 'created_at' ?>">
        <input type="submit" name="submit" value="Wijzig">
    </form>

</body>

</html>