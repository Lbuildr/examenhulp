<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-kassa_keuken_obers_bar-page.css">
    <title>EDIT-BESTELD-DRANK</title>
</head>

<body>

    <?php

    include_once 'Database.php';
    $db =  new database();

    if (isset($_GET['bestelling_drank_id'])){
    $sql = "SELECT * FROM bestelling_drank WHERE bestellingsnummer_drank=:code";
    $result = $db->select($sql, ['code' => $_GET['bestelling_drank_id']]);
    if (count($result) > 0) {
        $hoort_bij_tafel_nr = $result[0]['hoort_bij_tafel_nr'];
        $drank1 = $result[0]['drank1'];
        $drank2 = $result[0]['drank2'];
        $drank3 = $result[0]['drank3'];
        $drank4 = $result[0]['drank4'];
        $drank5 = $result[0]['drank5'];
    }
}


if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE bestelling_drank SET hoort_bij_tafel_nr=:hoort_bij_tafel_nr, drank1=:drank1, drank2=:drank2, drank3=:drank3, drank4=:drank4, drank5=:drank5 WHERE bestellingsnummer_drank = :code;";

        $placeholders = [
            'code' => $_POST['bestellingsnummer_drank'],
            'hoort_bij_tafel_nr' => $_POST['hoort_bij_tafel_nr'],
            'drank1' => $_POST['drank1'],
            'drank2' => $_POST['drank2'],
            'drank3' => $_POST['drank3'],
            'drank4' => $_POST['drank4'],
            'drank5' => $_POST['drank5'],
        ];

        $db->update($sql, $placeholders,"bar-page.php" );
    }
    ?>


    <form class="form" action="edit_bestel_drank.php" method="post">
        <input type="hidden" name="bestellingsnummer_drank" value="<?php echo isset($_GET['bestelling_drank_id']) ? $_GET['bestelling_drank_id'] : ''; ?>">
        <input class="input" type="text" name="hoort_bij_tafel_nr" value="<?php echo isset($hoort_bij_tafel_nr) ? $hoort_bij_tafel_nr : 'hoort_bij_tafel_nr' ?>">

        <select class="input" name="drank1" placeholder="<?php echo isset($drank1) ? $drank1 : 'drank1' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  
  <select class="input" name="drank2" placeholder="<?php echo isset($drank2) ? $drank2 : 'drank2' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>

  <select class="input" name="drank3" placeholder="<?php echo isset($drank3) ? $drank3 : 'drank3' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  
  <select class="input" name="drank4" placeholder="<?php echo isset($drank4) ? $drank4 : 'drank4' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
  
  <select class="input" name="drank5" placeholder="<?php echo isset($drank5) ? $drank5 : 'drank5' ?>">  
  <optgroup label="Koude dranken">
      <option selected="selected" value="0">selecteer drank</option>
      <option value="c-drank">Coca cola</option>
      <option value="c-zero">Coca Cola Zero </option>
      <option value="p-drank">Pepsi</option>
      <option value="p-zero">Pepsi Max</option>
      <option value="choco-drank-koud">Chocomelk </option>
      <option value="fristi">Fristi </option>
      <option value="b-drank">Biter lemon </option>
      <option value="fanta">Fanta </option>
    </optgroup>
    <optgroup label="Warme drank">
      <option value="Kofie">Kofie</option>
      <option value="capucino">Capucino </option>
      <option value="espresso">Espresso</option>
      <option value="late-machiato">Late machiato </option>
      <option value="C-drank-warm">Chocomelk </option>
    </optgroup>
    <optgroup label="Alcohol">
      <option value="rode-wijn">Rode wijn </option>
      <option value="witte-wijn">Witte wijn </option>
      <option value="heineken">Heineken </option>
      <option value="heineken-0%">Heineken 0% </option>
      <option value="grolsch-bier">Grolsch </option>
    </optgroup>
</select>
 
  <input id="button-voegtoe" type="submit" name="submit" value="Pas bestelling aan">
    </form>
</body>

</html>