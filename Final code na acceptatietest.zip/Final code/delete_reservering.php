<?php

if(isset($_GET['reservatie_id'])){

    $sql = "DELETE FROM reservaties WHERE reservatienummer=:reservatie_id";

    $placeholders = ['reservatie_id' => $_GET['reservatie_id']];


    include_once 'Database.php';

    $db =  new database();

    $db->delete($sql, $placeholders, 'kassa-page.php');


}else{

}


