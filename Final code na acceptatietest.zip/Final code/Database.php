<?php

class database
{

    private $host;
    private $username;
    private $password;
    private $database;
    private $dbh;

    public function __construct()
    {
        $this->host = 'localhost';
        $this->username = 'root';
        $this->password = '';
        $this->database = 'Examen_database';

        try {

            $dsn = "mysql:host=$this->host;dbname=$this->database";
            $this->dbh = new PDO($dsn, $this->username, $this->password);
        } catch (PDOException $exception) {
            die("Connection failed!-> " . $exception->getMessage());
        }
    }

    public function select($statement, $named_placeholder)
    {
        $stmt = $this->dbh->prepare($statement);
        $stmt->execute($named_placeholder);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function update($statement, $named_placeholder, $locatie)
    {
        $stmnt = $this->dbh->prepare($statement);
        $stmnt->execute($named_placeholder);
        header("location: $locatie");
        exit();
    }

    public function delete($statement, $named_placeholder, $locatie)
    {
        $stmt = $this->dbh->prepare($statement);

        $stmt->execute($named_placeholder);

        header("location: $locatie");
        exit();
    }


    public function insert($sql, $named_placeholder_array, $locatie)
    {
        try {
            $this->dbh->beginTransaction();

            $statement = $this->dbh->prepare($sql);
            $statement->execute($named_placeholder_array);

            $this->dbh->commit();
            header("location: $locatie");
        } catch (Exception $e) {
            $this->dbh->rollback();
            echo $e->getMessage();
        }
    }
}
