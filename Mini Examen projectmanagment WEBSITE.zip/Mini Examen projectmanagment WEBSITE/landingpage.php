<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-landingpage.css">
    <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>

    <title>CatchMoreFish</title>



<script>
  // Wait for window load
  $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
<!-- End Preloader -->

</head>

<?php
if(isset($_SESSION['loggedin'])){
    include "menu-home-ingelogd.php";
 } else{ 
     include "menu-home-geen-acc.php";
} ?>

<body>
<div class="se-pre-con"></div>
<!--------------------------------------------  -------------------------------------------------->
<?php
if(isset($_SESSION['loggedin'])){

} else{ 
     include "loginpage.php";
} ?>


<!-------------------------------------------- FOOTER -------------------------------------------------->

  <?php include "footer-main.php" ?>
  <script>
   $('.se-pre-con').fadeOut();
  </script>
  </body>
</html>