<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style-beheer-winkel.css">
  <title>BEHEER-WINKEL</title>
</head>
<body>
  





<?php include "menu-back-end.php"; ?>

<div class="content">
<!------------Winkel Column-------------->
  <?php
  include_once 'Database.php';
  $db = new database();
  $winkel = $db->select("SELECT * FROM winkel", []);

  $columns = array_keys($winkel[0]);
  $row_data = array_values($winkel);

  ?>

  <table id="winkel">
    <tr>
      <?php foreach ($columns as $column) { ?>
        <th>
          <strong>
            <?php echo $column; ?>
          </strong>
        </th>

      <?php    }    ?>
      <th colspan="3">actie</th>
    </tr>
    <?php foreach ($row_data as $row) { ?>
      <tr>
        <?php

        $winkel_id = $row['winkelcode'];

        foreach ($row as $data) { ?>
          <td>
            <?php echo $data; ?>
          </td>
        <?php } ?>

        <td>
          <a class="tooltip" href="edit_winkel.php?winkel_id=<?php echo $winkel_id ?>"><i class="fas fa-pencil-alt"></i>
            <p class="tooltiptext">Edit</p>
          </a>

          <a class="tooltip" href="delete_winkel.php?winkel_id=<?php echo $winkel_id ?>"><i class="fas fa-trash-alt"></i>
            <p class="tooltiptext">Delete</p>
          </a>
        </td>
      <?php
    }
      ?>

      </tr>

  </table>
  <form action="nieuw_winkel.php" method="post">
    <input class="voegtoe" type="submit" value="Zet een nieuwe winkel op de kaart">
  </form>
</div>

  </body>
</html>