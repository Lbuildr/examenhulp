<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT-PERSONEEL</title>
</head>

<body>

    <?php

    // importeer database
    include_once 'Database.php';

    // maak een db instance
    $db =  new database();

//hier zorgen we ervoor dat de website blijft weten om welk personeels lid het gaat
    if (isset($_GET['personeels_id'])){
    $sql = "SELECT * FROM personeel WHERE personeelscode=:code";
    $result = $db->select($sql, ['code' => $_GET['personeels_id']]);
    if (count($result) > 0) {
        $naam = $result[0]['naam'];
        $achternaam = $result[0]['achternaam'];
        $email = $result[0]['email'];
    }
}


//eerst checken we of de wijzig button geklikt is & dan checken we of de request method(request naar de server een post is)
if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE personeel SET naam=:naam, achternaam=:achternaam, email=:email WHERE personeelscode = :code;";
        // $sql = "UPDATE personeel SET"; //naam=:naam, achternaam=:achternaam, email=:email WHERE personeelscode = :code;";

        // foreach($_POST as $kolom){
        //     if($kolom == 'naam'){
        //         $sql .= ' naam=:naam';
        //     }

        //     if($kolom == 'achternaam'){
        //         $sql 
        //     }
        // }


        //associative array 
        $placeholders = [
            'code' => $_POST['personeelscode'],
            'naam' => $_POST['naam'] ,
            'achternaam' => $_POST['achternaam'],
            'email' => $_POST['email']
        ];

        // roep functie aan uit je database class
        $db->update($sql, $placeholders,"beheer-medewerker.php" );
    }
    ?>

<!--NOOIT GEBRUIKER VRAGEN OM HANDMATIG ID IN DATABASE TE WIJZIGEN-->
    <form action="edit_medewerker.php" method="post">
        <input type="hidden" name="personeelscode" value="<?php echo isset($_GET['personeels_id']) ? $_GET['personeels_id'] : ''; ?>">
        <input type="text" name="naam" value="<?php echo isset($naam) ? $naam : 'naam' ?>">
        <input type="text" name="achternaam" value="<?php echo isset($achternaam) ? $achternaam : 'achternaam' ?>">
        <input type="text" name="email" value="<?php echo isset($email) ? $email : 'email' ?>">
        <input type="submit" name="submit" value="Wijzig">
    </form>

</body>

</html>