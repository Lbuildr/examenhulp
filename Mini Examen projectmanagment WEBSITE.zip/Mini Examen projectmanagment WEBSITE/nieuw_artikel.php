<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>ARTIKEL-TOEVOEGEN</title>
</head>

<body>

    <?php

    // importeer
    include_once 'Database.php';

    if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "INSERT INTO producten VALUES (:code, :artikel, :prijs, :voorraad)";

        //associative array
        $placeholders = [
            'code' => NULL,
            'artikel' => $_POST['artikel'],
            'prijs' => $_POST['prijs'],
            'voorraad' => $_POST[ 'voorraad']
        ];

        $db = new database();
        $db->insert($sql, $placeholders, 'beheer-artikel.php');
    }
    ?>

    <form class="nieuwartikel" action="nieuw_artikel.php" method="post">
        <input class="input" type="text" name="artikel" placeholder="artikel">
        <input class="input" type="text" name="prijs" placeholder="prijs">
        <input class="input" type="text" name="voorraad" placeholder="voorraad">
        <input class="voegtoe" type="submit" name="submit" value="Artikel Toevoegen">
    </form>

</body>
<style>
    .voegtoe{
        border-radius: 10px;
        color:black;
        background: white;
        padding: 5px;
        border: 2px solid lightblue;
        cursor:pointer;
        text-decoration: none;
    }

    .input{
        width: 350px;
        border-radius: 10px;
        color:black;
        background: white;
        padding: 5px;
        border: 2px solid lightblue;
        text-decoration: none;
    }

    .nieuwartikel {
        position: absolute;
        bottom: 20px;
        left: 30%;
        background-color: white;
        border-radius: 10px;
        padding: 10px;
        width: 60%;
    }
</style>

</html>