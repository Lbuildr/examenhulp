<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>WINKEL-TOEVOEGEN</title>
</head>

<body>
<?php include "back_end_menu-employee.php"; ?>

    <?php

    // importeer
    include 'Database.php';

    if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "INSERT INTO winkel VALUES (:code, :naam, :adres, :postcode, :vestp, :tell)";

        //associative array
        $placeholders = [
            'code' => NULL,
            'naam' => $_POST['winkelnaam'],
            'adres' => $_POST['winkeladres'],
            'postcode' => $_POST['winkelpostcode'],
            'vestp' => $_POST['vestigingsplaats'],
            'tell' => $_POST['telefoonnummer']
        ];

        $db = new database();
        $db->insert($sql, $placeholders, 'back_end_employee-page.php');
    }
    ?>


    <form class="form" action="nieuw_winkel.php" method="post">
        <input type="text" name="winkelnaam" placeholder="winkelnaam" required>
        <input type="text" name="winkeladres" placeholder="winkeladres" required>
        <input type="text" name="winkelpostcode" placeholder="winkelpostcode" required>
        <input type="text" name="vestigingsplaats" placeholder="vestigingsplaats" required>
        <input type="text" name="telefoonnummer" placeholder="telefoonnummer">
        <input type="submit" name="submit" value="winkel op de kaart zetten">
    </form>

</body>
<style>
    #html{
    background: linear-gradient(95deg, #5533ff 40%, #25ddf5 100%);
    }
    .input{
        width: 350px;
        border-radius: 10px;
        color:black;
        background: white;
        padding: 5px;
        border: 2px solid lightblue;
        text-decoration: none;
    }

    .form {
        position: absolute;
        bottom: 20px;
        left: 30%;
        background-color: white;
        border-radius: 10px;
        padding: 10px;
        width: 60%;
    }
    </style>
</html>