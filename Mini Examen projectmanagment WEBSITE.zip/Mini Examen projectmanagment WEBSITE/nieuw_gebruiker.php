  <?php

    // importeer
    include_once 'Database.php';

    if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "INSERT INTO gebruikers VALUES (:code, :voornaam, :achternaam, :gebruikersnaam, :wachtwoord, :straatnaam, :huisnummer, :postcode, :stad, :usertype )";

        //associative array
        $placeholders = [
            'code' => NULL,
            'voornaam' => $_POST['voornaam'],
            'achternaam' => $_POST['achternaam'],
            'gebruikersnaam' => $_POST['gebruikersnaam'],
            'wachtwoord' => $_POST['wachtwoord'],
            'straatnaam' => $_POST['straatnaam'],
            'huisnummer' => $_POST['huisnummer'],
            'postcode' => $_POST['postcode'],
            'stad' => $_POST['stad'],
            'usertype' => $_POST['usertype']
        ];

        $db = new database();
        $db->insert($sql, $placeholders, 'beheer-gebruiker.php');
    }
    ?>


  <form class="form" action="nieuw_gebruiker.php" method="post">
      <input type="text" name="voornaam" placeholder="<?php echo isset($voornaam) ? $voornaam : 'voornaam' ?>">
      <input type="text" name="achternaam" placeholder="<?php echo isset($achternaam) ? $achternaam : 'achternaam' ?>">
      <input type="text" name="gebruikersnaam" placeholder="<?php echo isset($gebruikersnaam) ? $gebruikersnaam : 'gebruikersnaam' ?>">
      <input type="text" name="wachtwoord" placeholder="<?php echo isset($wachtwoord) ? $wachtwoord : 'wachtwoord' ?>">
      <input type="text" name="straatnaam" placeholder="<?php echo isset($straatnaam) ? $straatnaam : 'straatnaam' ?>">
      <input type="text" name="huisnummer" placeholder="<?php echo isset($huisnummer) ? $huisnummer : 'huisnummer' ?>">
      <input type="text" name="postcode" placeholder="<?php echo isset($postcode) ? $postcode : 'postcode' ?>">
      <input type="text" name="stad" placeholder="<?php echo isset($stad) ? $stad : 'stad' ?>">
      <select name="usertype" placeholder="<?php echo isset($usertype) ? $usertype : 'usertype' ?>">  
      <option value="1">Ceo</option>
        <option value="2">Filiaalmanager</option>
        <option value="3">Personeel</option>
      </select>
      <input type="submit" name="submit" value="join the club!">
  </form>

  </body>
  <style>
      #html{
    background: linear-gradient(95deg, #5533ff 40%, #25ddf5 100%);
    }
    .input{
        width: 350px;
        border-radius: 10px;
        color:black;
        background: white;
        padding: 5px;
        border: 2px solid lightblue;
        text-decoration: none;
    }

    .form {
        position: absolute;
        bottom: 20px;
        left: 30%;
        background-color: white;
        border-radius: 10px;
        padding: 10px;
        width: 60%;
    }
  </style>