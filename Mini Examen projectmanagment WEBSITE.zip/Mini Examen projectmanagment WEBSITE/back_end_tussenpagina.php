<?php
session_start();
if(isset($_SESSION['loggedin'])){
include_once "Database.php";


$usertype_id = $_SESSION['usertype_id'];
switch ($usertype_id) {

    case 1://Ceo
        header('Location: Back_end_admin-page.php');
    break;
    case 2://filiaalmanager
        header('Location: back_end-fm-page.php');
    break;
    case 3://personeel
        header('Location: dashboard.php');
    break;
    case 4://klant
        header('Location: account.php');
    break;
}
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tussen-pagina</title>
</head>
<body>


</body>
</html>