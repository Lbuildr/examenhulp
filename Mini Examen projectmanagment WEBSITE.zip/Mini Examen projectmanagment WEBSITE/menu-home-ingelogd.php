  <link rel="stylesheet" href="style-menu-home.css">


<input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon"/>
  <label for="menu-icon"></label>
  <nav class="nav"> 		
    <ul class="pt-5">
      <li><a href="#" target ="_self">Producten</a></li>
      <li><a href="#" target ="_self">Over Catch A Fish</a></li>
      <li><a href="back_end_tussenpagina.php" target ="_self">Account</a></li>
      <li><a href="loguit.php" id="signout" target ="_self" class="navigation-link">loguit</a></li>
    </ul>
  </nav>