  <link rel="stylesheet" href="style-menu-home.css">

  <input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon"/>
  	<label for="menu-icon"></label>
  	<nav class="nav"> 		
  		<ul class="pt-5">
  			<li><a href="#">Producten</a></li>
  			<li><a href="#">Over ons</a></li>
  			<li><a href="loginpage.php">Inloggen</a></li>
  		</ul>
  	</nav>

  </div>