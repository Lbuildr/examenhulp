<script>
    function uitloggen(){
        var loguit = confirm('Weet u zeker dat u wilt uitloggen?');
        if(loguit){
            location.href='index.php?page=uitloggen';
        }
    }
    

</script>
<header>
<script src="https://kit.fontawesome.com/4f8af57439.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="menu-style1.css">
</header>

<body>
  <nav>
    <div class="header">
      <div class="logo">Camping Village <i class="fas grey fa-campground"></i><div>
        <div class="header-bellow">
          <a href="index.php">Home</a>
          <a href="/#Reserveren">Reserveren</a>
          <a href="Contact.php">Activiteiten</a>
          <a href="Contact.php">Contact</a>
          <a href="Index-login.php">Inloggen</a>
          <a onclick="uitloggen()">Loguit</a> 
        </div>
    </div>
    <script>
    const currentLocation = location.href;
    const menuItem = document.querySelectorAll('a');
    const menuLength = menuItem.length
    for (let i = 0; i<menuLength; i++){
      if(menuItem[i].href === currentLocation){
        menuItem[i].className = "active"
      }
    }
    </script>
  </nav>
<!-----JAVASCRIPT------>
<script>
// ----------------NAVIGATION SHOW/HIDE--------------------------
$("nav ul").hide();

$(".nav-toggle").click( function() {
  $("nav ul").slideToggle("medium");
});

$("nav ul li a, .brand a").click( function() {
  $("nav ul").hide();
});


//---- SMOOTH SCROLLING WITH NAV HEIGHT OFFSET-------------------
$(function() {
  var navHeight = $("nav").outerHeight();
  $('a[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: target.offset().top - navHeight
        }, 1000);
        return false;
      }
    }
  });
});

//--------------- NAVIGATION STICKY-----------------------------

var viewHeight = $(window).height();
var navigation = $('nav');

$(window).scroll( function() {
  if ( $(window).scrollTop() > (viewHeight - 175) ) {  //edit voor nav height
    navigation.addClass('sticky');
  } else {
    navigation.removeClass('sticky');
  }
});
</script>
</body>
 