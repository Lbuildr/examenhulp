<link rel="stylesheet" href="menu-style2.css">

<div id="navbar">
  <a id="terug-button" href="landingpage.php"><i id="icon"class="lni lni-arrow-left-circle"></i> Terug naar Site</a>
  <a id="beheer-button" href="back_end_employee-page.php"><i id="icon" class="lni lni-briefcase"></i> Beheer-pagina</a>
  <a id="artikel-button" href="beheer-artikel.php"><i class="fas fa-shopping-cart"></i> artikel-beheer</a>
  <a id="personeel-button" href="beheer-gebruiker.php"><i class="fas fa-user-cog"></i> personeel-beheer</a>
  <a id="winkel-button" href="beheer-winkel.php"><i class="fas fa-store"></i> winkel-beheer</a>
  <a id="loguit-button" onclick="uitloggen()">Loguit</a>
</div>

<script type="text/javascript">
      const currentLocation = location.href;
      const menuItem = document.querySelectorAll('a');
      const menuLength = menuItem.length
      for (let i = 0; i < menuLength; i++) {
        if (menuItem[i].href === currentLocation) {
          menuItem[i].className = "active"
        }
      }

window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}

//--------------------UITLOGGEN---------------------------------------------
function uitloggen() {
        var loguit = confirm('Weet u zeker dat u wilt uitloggen?');
        if (loguit) {
          location.href = 'loguit.php';
        }
      }
      //--------------- NAVIGATION transparent-> white -----------------------------

      window.addEventListener('scroll', function() {
        let header = document.querySelector('header');
        let windowPosition = window.scrollY > 0;
        header.classList.toggle('scrolling-active', windowPosition);
      })

      //======================Page Loader active==================================*/
      $('#preloader').fadeOut();

      document.getElementById("#personeel-button").style.display = "none";
    </script>